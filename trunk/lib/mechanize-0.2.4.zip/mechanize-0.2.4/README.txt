See INSTALL.txt for installation instructions.

See docs/html/index.html and docstrings for documentation.

If you have a git working tree rather than a release, you'll only have
the markdown source, e.g. mechanize/index.txt; release.py is used to
build the HTML docs.
